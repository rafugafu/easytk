import tkinter as tk
from tkinter import ttk
try:
	from ttkthemes import ThemedStyle as Style
except:
	from tkinter.ttk import Style
from tkinter import colorchooser as cc
from tkinter import filedialog as fd
from tkinter import scrolledtext as st
from tkinter import messagebox as mb
import os
def label(widget, text, color = 'lightyellow', border = 'raised', master = None):
	_s = Style(master)
	_s.configure('Custom.TLabel', background = color)
	lr = ttk.Label(master, relief = border, text = text, style = 'Custom.TLabel')
	widget.bind('<Enter>', lambda event: [lr.place(x = event.widget.winfo_x() + event.widget.winfo_width() - 20, y = event.widget.winfo_y() + event.widget.winfo_height() - 10), lr.lift()])
	widget.bind('<Leave>', lambda event: lr.place_forget())
def strok(ans):
	global strans
	strans = ans
def askstring(title, prompt):
	root = tk.Tk()
	root.title(title)
	s = Style(root)
	try:
		s.theme_use('breeze')
	except:
		s.theme_use('clam')
	tf = ttk.Frame(root)
	tf.grid(padx = 5, pady = 5)
	ttk.Label(tf, text = prompt).pack(padx = 5, pady = 5)
	ans_ = ttk.Entry(tf)
	ans_.pack(fill = 'x', padx = 5, pady = 5)
	bf = ttk.Frame(root)
	bf.grid(padx = 5, pady = 5)
	ttk.Button(bf, text = 'Cancel', command = root.destroy).pack(side = 'left', padx = 5, pady = 5)
	ttk.Button(bf, text = 'OK', command = lambda: strok(ans_.get())).pack(side = 'right', padx = 5, pady = 5)
	root.bind('<Return>', lambda event: strok(ans_.get()))
	root.update()
	root.minsize(width = root.winfo_width(), height = root.winfo_height())
	root.maxsize(width = root.winfo_width(), height = root.winfo_height())
	while True:
		try:
			root.winfo_exists()
		except:
			return None
		else:
			try:
				global strans
				strans
			except:
				root.lift()
				ans_.focus()
				root.update()
			else:
				print('Hurray!')
				strans_ = strans
				del strans
				root.destroy()
				return strans_
class file():
	def lfilter(self, filetype):
		if filetype != 'all':
			self.files.delete(0, 'end')
			for self._file in sorted(os.listdir()):
				self.fileext = os.path.splitext(self._file)[1].removeprefix('.')
				if os.path.isdir(self._file):
					self.files.insert('end', self._file + '/')
				elif len(self._file.split('.')) > 1 and self.fileext == filetype:
					self.files.insert('end', self._file)
		else:
			self.files.delete(0, 'end')
			try:
				for self._file in sorted(os.listdir()):
					self.fileextfake = self._file.split('.')[1:]
					self.fileext = ''
					for s in self.fileextfake:
						self.fileext += s
					if os.path.isdir(self._file):
						self.files.insert('end', self._file + '/')
					else:
						self.files.insert('end', self._file)
			except PermissionError as error:
				self.root.error('[Errno 13]', error)
				self.open_('..')
	def getgeo(self, win):
		return [win.winfo_width(), win.winfo_height()]
	def openfile(self, types):
		self.root = tk.Tk()
		self.root.title('Open file')
		self.s = Style(self.root)
		try:
			self.s.theme_use('breeze')
		except:
			self.s.theme_use('clam')
		self.ff = ttk.Frame(self.root)
		self.ff.grid(column = 0, row = 0, padx = 20, pady = 20)
		self.fff = ttk.Frame(self.ff)
		self.fff.pack(fill = 'both', side = 'bottom')
		self.scroll = ttk.Scrollbar(self.fff)
		self.scroll.pack(fill = 'y', side = 'right')
		self.files = tk.Listbox(self.fff, width = 100, height = 10, yscrollcommand = self.scroll.set)
		self.files.pack(fill = 'both', side = 'bottom')
		self.files.bind('<ButtonRelease-1>', lambda event: self.highlight())
		self.files.bind('<Double-Button-1>', lambda event: self.open_())
		self.scroll.config(command = self.files.yview)
		self.dirshow = ttk.Label(self.ff)
		self.dirshow.pack(side = 'top', fill = 'x')
		self.file = ttk.Entry(self.ff, state = 'disabled')
		self.types = tk.StringVar()
		self.types.set(types[0])
		self.open_(os.getcwd())
		self.back = ttk.Button(self.ff, text = '<', command = lambda: self.open_('..'))
		self.back.pack(side = 'left')
		label(self.back, text = 'Back', master = self.ff)
		self.file.pack(side = 'top', fill = 'x')
		ttk.Button(self.root, text = 'Cancel', command = self.root.destroy).grid(column = 0, row = 1, sticky = 'w', padx = 20, pady = 20)
		ttk.OptionMenu(self.root, self.types, types[0], *types, command = lambda val: [self.lfilter(val)]).grid(column = 0, row = 1, padx = 20, pady = 20)
		ttk.Button(self.root, text = 'Open', command = lambda: self.open_()).grid(column = 0, row = 1, sticky = 'e', padx = 20, pady = 20)
		self.root.update()
		self.root.minsize(width = self.getgeo(self.root)[0], height = self.getgeo(self.root)[1])
		self.root.maxsize(width = self.getgeo(self.root)[0], height = self.getgeo(self.root)[1])
		while True:
			try:
				self.root.winfo_exists()
			except:
				try:
					self.done
				except:
					return None
				else:
					return self.done
			else:
				self.root.lift()
				self.root.update()
	def savefile(self):
		types = ['all']
		self.root = tk.Tk()
		self.s = Style(self.root)
		try:
			self.s.theme_use('breeze')
		except:
			self.s.theme_use('clam')
		self.root.title('Save file')
		self.ff = ttk.Frame(self.root)
		self.root.bind('<Return>', lambda event: self.save())
		self.ff.grid(column = 0, row = 0, padx = 20, pady = 20)
		self.fff = ttk.Frame(self.ff)
		self.fff.pack(fill = 'both', side = 'bottom')
		self.scroll = ttk.Scrollbar(self.fff)
		self.scroll.pack(fill = 'y', side = 'right')
		self.files = tk.Listbox(self.fff, width = 100, height = 10, yscrollcommand = self.scroll.set)
		self.files.pack(fill = 'both', side = 'bottom')
		self.files.bind('<ButtonRelease-1>', lambda event: self.highlight())
		self.files.bind('<Double-Button-1>', lambda event: self.save())
		self.scroll.config(command = self.files.yview)
		self.dirshow = ttk.Label(self.ff)
		self.dirshow.pack(side = 'top', fill = 'x')
		self.file = ttk.Entry(self.ff)
		self.types = tk.StringVar(value = types[0])
		self.open_(os.getcwd())
		self.new = ttk.Button(self.ff, text = '+', command = self.mnd)
		label(self.new, text = 'New directory', master = self.ff)
		self.new.pack(side = 'left')
		self.back = ttk.Button(self.ff, text = '<', command = lambda: self.open_('..'))
		self.back.pack(side = 'left')
		label(self.back, text = 'Back', master = self.ff)
		self.file.pack(side = 'top', fill = 'x')
		ttk.Button(self.root, text = 'Cancel', command = self.root.destroy).grid(column = 0, row = 1, sticky = 'w', padx = 20, pady = 20)
		ttk.OptionMenu(self.root, self.types, types[0], *types, command = lambda val: [self.lfilter(val)]).grid(column = 0, row = 1, padx = 20, pady = 20)
		ttk.Button(self.root, text = 'Save', command = lambda: self.save()).grid(column = 0, row = 1, sticky = 'e', padx = 20, pady = 20)
		self.root.update()
		self.root.minsize(width = self.getgeo(self.root)[0], height = self.getgeo(self.root)[1])
		self.root.maxsize(width = self.getgeo(self.root)[0], height = self.getgeo(self.root)[1])
		while True:
			try:
				self.root.winfo_exists()
			except:
				try:
					self.done
				except:
					return None
				else:
					return self.done
			else:
				self.root.lift()
				self.file.focus()
				self.root.update()
	def mnd(self):
		nd = askstring('New dir', '')
		if nd:
			try:
				os.mkdir(nd)
			except FileExistsError:
				self.root.error('Error', 'A directory with that name already exists')
			else:
				self.open_('.')
	def highlight(self):
		self.file.delete(0, 'end')
		try:
			self.file.insert('end', self.files.get(self.files.curselection()[0]))
		except:
			pass
	def open_(self, dir_ = None):
		if dir_ == None:
			try:
				if self.files.get(self.files.curselection()[0])[len(self.files.get(self.files.curselection()[0])) - 1] == '/':
					self.open_(self.files.get(self.files.curselection()[0]))
				else:
					self.done = os.path.join(os.getcwd(), self.files.get(self.files.curselection()[0]))
					self.root.destroy()
					return
			except:
				pass
		else:
			os.chdir(dir_)
			self.dirshow.config(text = os.getcwd())
			self.file.delete(0, 'end')
		self.lfilter(self.types.get())
	def save(self):
		if self.file.get()[len(self.file.get()) - 1] == '/':
			self.open_(self.files.get(self.files.curselection()[0]))
		elif self.file.get():
			if os.path.exists(os.path.join(os.getcwd(), self.file.get())):
				if mb.askyesno('WARNING', 'A file named "{}" already exists. Do you want to replace it?'.format(self.file.get())):
					self.done = os.path.join(os.getcwd(), self.file.get())
					self.root.destroy()
					return
			else:
				self.done = os.path.join(os.getcwd(), self.file.get())
				self.root.destroy()
				return
root = tk.Tk()
root.title('easytk test')
s = Style(root)
try:
	s.theme_use('breeze')
except:
	s.theme_use('clam')
t = ttk.Notebook(root)
at = ttk.Frame(root)
bt = ttk.Frame(root)
t.add(at, text = 'Tab1')
t.add(bt, text = 'Tab2')
t.pack(padx = 10, pady = 10)
scrolly = ttk.Scrollbar(root, orient = 'vertical')
scrolly.pack(side = 'right', fill = 'y')
scrollytwo = ttk.Scrollbar(root, orient = 'horizontal')
scrollytwo.pack(side = 'bottom', fill = 'x')
listy = tk.Listbox(root, width = 10, yscrollcommand = scrolly.set, xscrollcommand = scrollytwo.set)
listy.pack(side = 'right', fill = 'both')
for i in range(10000000000000000000, 10000000000000000050):
	listy.insert('end', str(i))
scrollytwo.config(command = listy.xview)
scrolly.config(command = listy.yview)
def openfile(types = ['all', 'py']):
	return file().openfile(types)
def savefile():
	return file().savefile()
def setset__(event):
	s.theme_use(varvar.get())
def setset_(event):
	text.config(text = str(droptype.get()))
def setset():
	text.config(text = str(checkvar.get()))
def set_(event):
	text.config(text = str(round(slider.get())))
def set__(event):
	text.config(text = str(var.get()))
def set___():
	text.config(text = stringvar.get())
def askcolor(*args, **kwargs):
	c = cc.askcolor(*args, **kwargs)
	if c[1]:
		return c[1]
	else:
		return None
slider = ttk.Scale(root, from_ = 1, to = 100, command = set_)
slider.pack()
ttk.Progressbar(root, length = 200, value = 50).pack()
im1 = tk.PhotoImage(file = 'ScorPyon.png').subsample(20, 20)
b = ttk.Button(root, text = 'something', image = im1, compound = 'left', command = lambda: mb.showinfo('something', openfile()))
b.pack()
ttk.Button(root, text = 'savefile', command = lambda: mb.showinfo(message = savefile(), title = 'something')).pack()
label(widget = b, text = 'hidden surprise!', master = root)
ttk.Button(root, text = 'something else', compound = 'left', command = lambda: mb.showinfo(message = askcolor(title = 'please choose a colour for poor something else or get ready to face the wrath of GREATNESS ITSELF!'), title = 'something else')).pack()
ttk.Button(root, text = 'something altogether different; otherwordly').pack()
checkvar = tk.BooleanVar(root)
ttk.Checkbutton(root, text = 'something ?', variable = checkvar, command = setset).pack()
stringvar = tk.StringVar()
text = ttk.Label(root)
text.pack()
imgs = []
def image(image, imsize = (10, 10), master = None):
	photo = tk.PhotoImage(file = image)
	photoimage = photo.subsample(imsize[0], imsize[1])
	imgs.append(photoimage)
	return ttk.Label(master, image = imgs[len(imgs) - 1])
image(image = 'DERSU.png', imsize = (1, 1), master = root).pack()
ttk.Label(at, text = 'Tab1').pack()
ttk.Label(bt, text = 'Tab2').pack()
image(master = at, image = 'ScorPyTex.png').pack()
image(master = bt, image = 'PyNotes.png').pack()
ttk.Radiobutton(root, text = 'Default', var = stringvar, value = 'Default', command = set___).pack(anchor = 'w')
ttk.Radiobutton(root, text = 'Something else altogether; otherwordly', var = stringvar, value = 'Something else altogether; otherwordly', command = set___).pack(anchor = 'w')
var = tk.StringVar()
ttk.OptionMenu(root, var, 'select', *'abc', command = set__).pack()
varvar = tk.StringVar()
ttk.OptionMenu(root, varvar, root.tk.call('ttk::style', 'theme', 'use'), *sorted(s.theme_names()), command = setset__).pack()
ttk.Spinbox(root, from_ = 0, to = 10).pack()
droptype = ttk.Combobox(root, values = ['gabuchi', 'babuchi', 'gabuchibabuchi'])
droptype.pack()
droptype.bind('<<ComboboxSelected>>', setset_)
ttk.Separator().pack(fill = 'x', pady = 10)
def selall():
	stst.tag_add('sel', '1.0', 'end')
	return 'break'
stst = st.ScrolledText(root, width = 20, height = 5)
stst.bind('<Control-a>', lambda event: selall())
stst.pack()
ttk.Entry(root).pack()
menu = tk.Menu(root)
root.config(m = menu)
a = tk.Menu()
menu.add_cascade(label = 'a', menu = a)
a.add_command(label = 'something')
m = tk.Menu()
a.add_cascade(label = 'something else', menu = m)
m.add_command(label = 'abc')
mm = tk.Menu()
m.add_cascade(label = 'abcd', menu = mm)
root.mainloop()