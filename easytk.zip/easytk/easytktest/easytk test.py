import easytk
root = easytk.win()
root.title('easytk test')
t = root.tabs()
true = True
at = root.frame()
bt = root.frame()
t.add(at, text = 'Tab1')
t.add(bt, text = 'Tab2')
t.pack(padx = 10, pady = 10)
scrolly = root.scroll(orient = 'vertical')
scrolly.pack(side = 'right', fill = 'y')
scrollytwo = root.scroll(orient = 'horizontal')
scrollytwo.pack(side = 'bottom', fill = 'x')
listy = root.listbox(width = 10, yscrollcommand = scrolly.set, xscrollcommand = scrollytwo.set)
listy.pack(side = 'right', fill = 'both')
for i in range(10000000000000000000, 10000000000000000050):
	listy.insert('end', str(i))
scrollytwo.config(command = listy.xview)
scrolly.config(command = listy.yview)
def setset__(event):
	root.style(varvar.get())
def setset_():
	text.config(text = str(droptype.get()))
def setset():
	text.config(text = str(checkvar.get()))
def set_(event):
	text.config(text = str(round(slider.get())))
def set__(event):
	text.config(text = str(var.get()))
def set___():
	text.config(text = stringvar.get())
def settrue():
	global true
	if true:
		true = False
	else:
		true = True
	if not true:
		p.config(value = 70, mode = 'determinate')
	else:
		p.config(mode = 'indeterminate')
		u()
slider = root.slider(range_ = [1, 100], command = set_)
slider.pack()
p = root.progressbar(length = 200, mode = 'indeterminate')
p.pack()
b = root.button(text = 'something', image = 'ScorPyon.png', imsize = (20, 20), command = lambda: root.info(message = root.openfile(), title = 'something'))
b.pack()
root.button(text = 'savefile', command = lambda: root.info(message = root.savefile(), title = 'something')).pack()
root.label(widget = b, text = 'hidden surprise!')
root.button(text = 'something else', compound = 'left', command = lambda: root.info(message = root.askcolor(title = 'please choose a colour for poor something else or get ready to face the wrath of GREATNESS ITSELF!'), title = 'something else')).pack()
root.button(text = 'something altogether different; otherwordly', command = settrue).pack()
checkvar = root.booleanvar()
root.check(text = 'something ?', variable = checkvar, command = setset).pack()
stringvar = root.stringvar()
text = root.text()
text.pack()
root.image(image = 'DERSU.png', imsize = (1, 1)).pack()
root.text(master = at, text = 'Tab1').pack()
root.text(master = bt, text = 'Tab2').pack()
root.image(master = at, image = 'ScorPyTex.png').pack()
root.image(master = bt, image = 'PyNotes.png').pack()
root.multiplechoice(text = 'Default', var = stringvar, command = set___).pack(anchor = 'w')
root.multiplechoice(text = 'Something else altogether; otherwordly', var = stringvar, command = set___).pack(anchor = 'w')
var = root.stringvar()
root.dropdown(var, 'select', 'abc', command = set__).pack()
varvar = root.stringvar()
root.dropdown(varvar, root.gettheme(), root.themes(), command = setset__).pack()
root.spinbox(range_ = [0, 10]).pack()
droptype = root.droptype(['gabuchi', 'babuchi', 'gabuchibabuchi'], command = setset_)
droptype.pack()
root.separator().pack(fill = 'x', pady = 10)
root.textbox(scrolled = True, width = 20, height = 5).pack()
root.entry().pack()
menu = root.menu()
root.config(m = menu)
a = root.menu()
menu.add_cascade(label = 'a', menu = a)
a.add_command(label = 'something')
m = root.menu()
a.add_cascade(label = 'something else', menu = m)
m.add_command(label = 'abc')
mm = root.menu()
m.add_cascade(label = 'abcd', menu = mm)
v = 0
def u():
	global v
	v += 1
	if true:
		p.config(value = v)
		root.after(15, u)
u()
root.show()